const express = require('express');
const app = express();
const PORT = 3000;

// Bootstrap'i statik dosya olarak kullanmak
app.use(express.static('node_modules/bootstrap/dist'));

// Ürün listesi (Daha fazla ürün eklendi)
const products = [
    { id: 1, name: "Laptop", price: 1000, description: "High-performance laptop", image: "https://via.placeholder.com/150" },
    { id: 2, name: "Smartphone", price: 500, description: "Latest model smartphone", image: "https://via.placeholder.com/150" },
    { id: 3, name: "Headphones", price: 100, description: "Noise-cancelling headphones", image: "https://via.placeholder.com/150" },
    { id: 4, name: "Smart Watch", price: 200, description: "Stylish smart watch", image: "https://via.placeholder.com/150" },
    { id: 5, name: "Tablet", price: 300, description: "Portable and powerful tablet", image: "https://via.placeholder.com/150" },
];

let cart = [];

// Pug view engine kullanımı
app.set('view engine', 'pug');
app.set('views', './views');
app.use(express.static('public'));

// Ana sayfa - Ürün listeleme
app.get('/', (req, res) => {
    res.render('index', { products });
});

// Ürün detay sayfası
app.get('/product/:id', (req, res) => {
    const product = products.find(p => p.id === parseInt(req.params.id));
    res.render('product', { product });
});

// Ürün sepete ekleme
app.get('/add-to-cart/:id', (req, res) => {
    const product = products.find(p => p.id === parseInt(req.params.id));
    cart.push(product);
    res.redirect('/cart');
});

// Sepetten ürün çıkarma
app.get('/remove-from-cart/:id', (req, res) => {
    cart = cart.filter(item => item.id !== parseInt(req.params.id));
    res.redirect('/cart');
});

// Sepet sayfası
app.get('/cart', (req, res) => {
    const total = cart.reduce((sum, item) => sum + item.price, 0);
    res.render('cart', { cart, total });
});

// Ödeme sayfası
app.get('/checkout', (req, res) => {
    res.render('checkout');
});

// Sunucuyu başlatma
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
